from django.apps import AppConfig


class NearappConfig(AppConfig):
    name = 'nearapp'
